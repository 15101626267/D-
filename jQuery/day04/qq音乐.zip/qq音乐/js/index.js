$(function(){
   let musicRender=(function(){
       // 获取歌词
      function getSyric(){
          $.ajax({
              url:"js/lyric.json",
              type:"get",
              success:function(data){
                 console.log(data);
              }
          })
      }
     
      return {
          //初始化的一些功能代码  
          init:function(){
              // 获取歌词
              getSyric()
          }
      }

   })();
   musicRender.init();











})